package za.co.svenlange.grails.plugins.tooltip

class ExampleController {

    def index = { }

    def custom = { }

}